package com.amazon.internalclassifieds;

import java.util.Date;

import com.amazon.internalclassifieds.controller.CategoryManagement;
import com.amazon.internalclassifieds.controller.ClassifiedManagement;
import com.amazon.internalclassifieds.controller.OrderManagement;
import com.amazon.internalclassifieds.controller.UserManagement;
import com.amazon.internalclassifieds.model.Users;

public class AdminMenu extends Menu {
	
	private static AdminMenu adminMenu = new AdminMenu();
	
	public static AdminMenu getInstance() {
		return adminMenu;
	}
	
	UserManagement manageUser = UserManagement.getInstance();
	ClassifiedManagement manageClassified = ClassifiedManagement.getInstance();
	CategoryManagement manageCategory = CategoryManagement.getInstance();
	OrderManagement manageOrder = OrderManagement.getInstance();
	
	
	public void showMenu() {
		System.out.println("Navigating to Admin Menu...");
		Users adminUser = new Users();
		System.out.println("Enter the emailID");
		adminUser.email = scanner.nextLine();
		System.out.println("Enter Password");
		adminUser.password = scanner.nextLine();
		
		boolean result = manageUser.login(adminUser);
		
		if(result && adminUser.userType == 1) {
		
			userSession.user = adminUser;
			
			System.out.println("*********************");
			System.out.println("Welcome to Admin App");
			System.out.println("Hello, "+adminUser.name);
			System.out.println("Its: "+new Date());
			System.out.println("*********************");
			
			boolean quit = false;
			
			while(true) {
				try {
					System.out.println("*********************");
		        	System.out.println("1: Approve/Reject Classifieds");
		        	System.out.println("2: Manage User");
		        	System.out.println("3: Add/Remove Classified");
		        	System.out.println("4: Manage Type/Categories of Classified");
		        	System.out.println("5: View Transactions Report");
		        	System.out.println("6: Quit Admin App");
		        	System.out.println("Select an Option");
		        	
		        	int choice = Integer.parseInt(scanner.nextLine());
		        	
		        	switch (choice) {
						case 1:
							manageClassified.approvalOfClassified();
							break;
							
						case 2:
							manageUser.activateUser();
							break;
		
						case 3:
							System.out.println("1. to post a classified");
							System.out.println("2. to remove a classified");
							System.out.println("Enter your choice");
							int ch = Integer.parseInt(scanner.nextLine());
							
							if (ch == 1)
								manageClassified.postClassified();
							else if (ch == 2)
								manageClassified.removeClassified();
							else
								System.err.println("Invalid Input");
							
							break;
							
						case 4:
							manageCategory.manageCategory();
							
							break;
							
						case 5:
							manageOrder.orderReport();
							
							break;
						
						case 6:
							System.out.println("Thank You for Using Admin App !!");
							quit = true;
							break;
					
						default:
							System.err.println("Invalid Choice...");
							break;
					}
		        	
		        	if(quit) {
		        		break;
		        	}
		        	
				}
				catch (Exception e) {
					System.err.println("Invalid Input:" +e);
				}
			}
		}
		
		else {
			System.err.println("Invalid Credentials. Please Try Again !!");
		}
	}
}
