package com.amazon.internalclassifieds;

import com.amazon.internalclassifieds.model.Users;

public class userSession {

	// Can hold the reference of a User Object :)
		public static Users user = null;
}
