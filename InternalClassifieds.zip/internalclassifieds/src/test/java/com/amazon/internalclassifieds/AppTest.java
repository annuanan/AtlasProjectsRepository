package com.amazon.internalclassifieds;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import org.junit.Assert;
import org.junit.Test;

import com.amazon.internalclassifieds.controller.UserManagement;
import com.amazon.internalclassifieds.db.UserDAO;
import com.amazon.internalclassifieds.model.Users;



// Reference Link to Use JUnit as Testing Tool in your Project
// https://maven.apache.org/surefire/maven-surefire-plugin/examples/junit.html

public class AppTest {
    
	UserManagement manageuser = UserManagement.getInstance();
	
	// UNIT TESTS
	
	@Test
	public void testUserLogin() {
		
		Users user = new Users();
		
		user.password = "annu123";
		user.email = "annu@example.com";
		
		boolean result = manageuser.login(user);
		
		// Assertion -> Either Test Cases Passes or It will Fail :)
		Assert.assertEquals(true, result);
		
	}
	
	@Test
	public void testUserRegisteration() {
		
		Users user = new Users();
		UserDAO userdao = new UserDAO();
		
		boolean result=false;
		
		user.address = "Kailash hills";
		user.email = "lost@example.com";
		user.name = "Happiness";
		user.password = "abcd";
		user.phone = "123456789";
		
		if (userdao.insert(user)>0)
			result = true;
		
		// Assertion -> Either Test Cases Passes or It will Fail :)
		Assert.assertEquals(true, result);
		
	}
	
}
	
	